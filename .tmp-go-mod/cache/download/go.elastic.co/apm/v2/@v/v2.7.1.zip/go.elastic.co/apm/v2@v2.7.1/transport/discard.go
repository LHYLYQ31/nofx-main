// Licensed to Elasticsearch B.V. under one or more contributor
// license agreements. See the NOTICE file distributed with
// this work for additional information regarding copyright
// ownership. Elasticsearch B.V. licenses this file to you under
// the Apache License, Version 2.0 (the "License"); you may
// not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing,
// software distributed under the License is distributed on an
// "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
// KIND, either express or implied.  See the License for the
// specific language governing permissions and limitations
// under the License.

package transport // import "go.elastic.co/apm/v2/transport"

import (
	"context"
	"io"
)

var (
	// Discard is a Transport on which all operations
	// succeed without doing anything.
	Discard = discardTransport{}
)

// NewDiscardTransport returns a Transport that returns the given
// error from all operations.
func NewDiscardTransport(err error) Transport {
	return discardTransport{err}
}

type discardTransport struct {
	err error
}

func (s discardTransport) SendStream(context.Context, io.Reader) error {
	return s.err
}
