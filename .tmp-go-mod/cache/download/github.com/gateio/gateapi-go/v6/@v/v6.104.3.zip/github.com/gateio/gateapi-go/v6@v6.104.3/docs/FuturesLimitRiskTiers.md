# FuturesLimitRiskTiers

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Tier** | **int32** | Tier | [optional] 
**RiskLimit** | **string** | Position risk limit | [optional] 
**InitialRate** | **string** | Initial margin rate | [optional] 
**MaintenanceRate** | **string** | Maintenance margin rate | [optional] 
**LeverageMax** | **string** | Maximum leverage | [optional] 
**Contract** | **string** | Market, only visible when market pagination is requested | [optional] 
**Deduction** | **string** | Maintenance margin quick calculation deduction amount | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


